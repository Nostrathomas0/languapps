Kerneling Phantom by HTML5 UP
html5up.net | @ajlkn
Languapps connects and sets up applications of language
Web design Free for personal and commercial use under the CCA 3.0 license (html5up.net/license)
This is Languapps, a network of discussion about language learning strategies. 
Developers testimonials from people who are learning language colorfully bare. This business networking 
platform is open to teacher entrepreneurs in collaboration with their arts.

nostrathomas@languapps.com  |	@BadLooksBook

This is Phrankon, a simple design built around a grid of large, colorful, semi-interactive
image tiles (of which can have as preference, or as few as you like). Makes use of some
SVG and animation techniques (https://carrd.co), and includes a handy generic page for whatever.

aj@lkn.io | @ajlkn
