GUIDE FOR CONTRIBUTERS
**contact** 
please mailto:growlroar@gmail.com with PRO in the subject

**guidelines**  
Use the app at least 5 times a week  
Write a few paragraphs about it
Include details about the app, as well as your experience with it. Send a picture and a screenshot, if you'd like to.
 
**example review**

If you're at a beginner or elementary level, and you like to drag and drop, this app is a fun visual way to learn words and phrases. You'll probably have fun with the neat voice recognition. You'll also learn words by matching icon-like images with audio samples and writen words. I used it for Chinese, and you get to draw the characters on your touch screen. They overlay pictures of what they represent; fish, knife.   

Drops uses spaced repetition sequencing to help with vocab but has neither speech recognition nor lengthy passages. It's far from comprehensive. It's basically a fun word game. Ads are light and you won't run into walls on the free version unless you want to use it a lot. At first you only get 5 minutes a day but as you play, you win additional time which is nice because of 10 hour wait time. You get access to word bank which will be pretty poor unless you buy it.  

Download it now and suppliment a grammar + conversation practice + reading and writing. Use it for a few minutes a day with focus to boost your vocabulary and have fun on a pared down app for great word input. ***
